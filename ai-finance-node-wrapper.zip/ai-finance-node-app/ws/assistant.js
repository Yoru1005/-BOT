const WebSocket = require('ws');

module.exports = (server) => {
  const wss = new WebSocket.Server({ server });

  wss.on('connection', (ws) => {
    ws.on('message', async (msg) => {
      const data = JSON.parse(msg);
      ws.send(JSON.stringify({ type: 'start' }));

      const fakeAdvice = '請減少娛樂開支，收入結餘不足以應付未來花費。';
      ws.send(JSON.stringify({ type: 'chunk', delta: fakeAdvice }));
      ws.send(JSON.stringify({ type: 'end' }));
    });
  });
};
